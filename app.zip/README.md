# Purple Admin Panel (Next.js + Firebase)

Admin signs in, adds users (name, email, password) and items (name, quantity). Mobile-first, purple theme.

## Setup
1. Firebase console: create a project, enable **Authentication > Email/Password**, create a **Firestore** database.
2. Project settings: add a Web app (copy config) and generate a **service account key**.
3. `cp .env.local.example .env.local` and fill it in (also set ADMIN_EMAIL / ADMIN_PASSWORD).
4. `npm install`
5. `npm run create-admin`  (creates the first admin account)
6. Publish `firestore.rules` (Firestore > Rules).
7. `npm run dev` and open http://localhost:3000

## How it stays secure and scalable
- Users are created server-side with the Firebase Admin SDK (so the admin isn't signed out).
- Every API route checks the caller's ID token has the `admin` claim.
- Firestore writes are blocked from the browser; lists are paginated (20 per page).
- Deploy on Vercel: add the same env vars in project settings.
